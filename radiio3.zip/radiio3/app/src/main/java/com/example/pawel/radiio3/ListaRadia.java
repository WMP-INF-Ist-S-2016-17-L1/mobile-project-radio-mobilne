package com.example.pawel.radiio3;

public class ListaRadia {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    String name;
    String uri;
    int image;

    public ListaRadia(String name, String uri, int image) {
        this.name = name;
        this.uri = uri;
        this.image = image;
    }
}

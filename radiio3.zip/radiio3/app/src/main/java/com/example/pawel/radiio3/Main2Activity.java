package com.example.pawel.radiio3;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {

    ListView listView;
    RadioArrayAdapter radioArrayAdapter;
    int image;
    ImageButton btnPlus;
    Context context = this;
    String uri;
    Intent intent;
    ProgressDialog progress;
    public static List<ListaRadia> lista = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnPlus = (ImageButton)findViewById(R.id.plus);
        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Main2Activity.this, Main3Activity.class));
            }
        });

        listView = (ListView) findViewById(R.id.listRadio);
        radioArrayAdapter = new RadioArrayAdapter(getApplicationContext(), R.layout.listviewitem);
        listView.setAdapter(radioArrayAdapter);

        SQLiteDatabase myDB =
                openOrCreateDatabase("my.db", MODE_PRIVATE, null);

        Cursor myCursor =
                myDB.rawQuery("select name, uri, img from user", null);
lista.clear();
        while(myCursor.moveToNext()) {
           // String name = myCursor.getString(0);
          //  Stri age = myCursor.getInt(1);
          //  boolean isSingle = (myCursor.getInt(2)) == 1 ? true:false;

            image =myCursor.getInt(2);

            lista.add(new ListaRadia(myCursor.getString(0),myCursor.getString(1),image ));
            radioArrayAdapter.add(new RadioAdapter( image,  myCursor.getString(0),myCursor.getString(1) ));
        }

       /* image =R.drawable.a1;
        radioArrayAdapter.add(new RadioAdapter( image,  "index 96 fm" ));

        image =R.drawable.a2;
        radioArrayAdapter.add(new RadioAdapter( image,  "Kampus" ));

        image =R.drawable.a3;
        radioArrayAdapter.add(new RadioAdapter( image,  "Radio LUZ" ));

        image =R.drawable.a4;
        radioArrayAdapter.add(new RadioAdapter( image,  "Anty Radio" ));

        image =R.drawable.a5;
        radioArrayAdapter.add(new RadioAdapter( image,  "Bon Ton" ));

        image =R.drawable.a6;
        radioArrayAdapter.add(new RadioAdapter( image,  "Polskie Radio" ));

        image =R.drawable.a7;
        radioArrayAdapter.add(new RadioAdapter( image,  "Parafia N.M.P" ));

        image =R.drawable.a8;
        radioArrayAdapter.add(new RadioAdapter( image,  "KRDP" ));

*/




listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        RadioAdapter selection = (RadioAdapter)   listView.getItemAtPosition(position);
      //  selection.uri;


        intent = new Intent(Main2Activity.this, MainActivity.class);
        intent.putExtra("text",   selection.name);
        intent.putExtra("uri",   selection.uri);
        intent.putExtra("image", selection.image);

        uri = selection.uri;

        progress = new ProgressDialog(context);
        progress.setTitle("Ładowanie");
        progress.setMessage("Proszę poczekać...");
        progress.setCancelable(false); // disable dismiss by tapping outside of the dialog
        progress.show();

       SearchThread searchThread = new SearchThread();
       searchThread.start();
     /*   MainActivity.mediaPlayer.pause();
        MainActivity.mediaPlayer.stop();
        MainActivity.mediaPlayer = new MediaPlayer();

        try {

            MainActivity.mediaPlayer.setDataSource(selection.uri);
            MainActivity.mediaPlayer.prepare();
        }
        catch (Exception ex)
        {
String e = ex.toString();
        }*/
MainActivity.nextI = position;

        String a = selection.uri;

   //     startActivity(intent);
       // startActivity(new Intent(Main2Activity.this, MainActivity.class));

    }
});


    }
    @Override
    public void onBackPressed() {

        Cursor myCursor =  MainActivity.myDB.rawQuery("select name, uri, img from user", null);
        lista.clear();
        while(myCursor.moveToNext()) {
            // String name = myCursor.getString(0);
            //  Stri age = myCursor.getInt(1);
            //  boolean isSingle = (myCursor.getInt(2)) == 1 ? true:false;

            image =myCursor.getInt(2);

            lista.add(new ListaRadia(myCursor.getString(0),myCursor.getString(1),image ));
          //  radioArrayAdapter.add(new RadioAdapter( image,  myCursor.getString(0),myCursor.getString(1) ));
        }

        intent = new Intent(Main2Activity.this, MainActivity.class);
        intent.putExtra("text",   MainActivity.text);
        intent.putExtra("image", MainActivity.image);
        startActivity(intent);

      //  startActivity(new Intent(Main2Activity.this, MainActivity.class));
    }
    private class SearchThread extends Thread {




        @Override
        public void run() {

            MainActivity.mediaPlayer.pause();
            MainActivity.mediaPlayer.stop();
            MainActivity.mediaPlayer = new MediaPlayer();

            try {

                MainActivity.mediaPlayer.setDataSource(uri);
                MainActivity.mediaPlayer.prepare();
            }
            catch (Exception ex)
            {
                String e = ex.toString();
            }

            handler.sendEmptyMessage(0);
        }

        private Handler handler = new Handler() {

            @Override
            public void handleMessage(Message msg) {
               // displaySearchResults(search);
                Cursor myCursor =  MainActivity.myDB.rawQuery("select name, uri, img from user", null);
                lista.clear();
                while(myCursor.moveToNext()) {
                    // String name = myCursor.getString(0);
                    //  Stri age = myCursor.getInt(1);
                    //  boolean isSingle = (myCursor.getInt(2)) == 1 ? true:false;

                    image =myCursor.getInt(2);

                    lista.add(new ListaRadia(myCursor.getString(0),myCursor.getString(1),image ));
                  //  radioArrayAdapter.add(new RadioAdapter( image,  myCursor.getString(0),myCursor.getString(1) ));
                }


                progress.dismiss();


                startActivity(intent);
            }
        };
    }
}

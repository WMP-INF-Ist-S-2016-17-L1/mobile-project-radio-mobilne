package com.example.pawel.radiio3;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main3Activity extends AppCompatActivity {


    private ArrayList<Boolean> checkBox = new ArrayList<>();
    private  ArrayList<Integer> img = new ArrayList<>();
    private ImageButton checked;
    private EditText ETname,ETuri;
    Cursor myCursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);



        ETname = (EditText)findViewById(R.id.DBname);
        ETuri = (EditText) findViewById(R.id.DBuri);

        checked = (ImageButton) findViewById(R.id.checked);
        checked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if((!ETname.getText().toString().equals("")) && !(ETuri.getText().toString().equals("")))

                {
                    Boolean addName = true;


                        myCursor = MainActivity.myDB.rawQuery("select name from user", null);

                    if(myCursor!=null && myCursor.getCount()>0)
                    {
                        while (myCursor.moveToNext()) {

                            if (ETname.getText().toString().toLowerCase().equals(myCursor.getString(0).toLowerCase()))
                                addName = false;


                        }
                    }
                    if (addName) {

                        ContentValues row1 = new ContentValues();

                    row1.put("name", ETname.getText().toString());
                    row1.put("uri", ETuri.getText().toString());
                    row1.put("img", RecyclerViewAdapter.imageForList);

                    MainActivity.myDB.insert("user", null, row1);

                    startActivity(new Intent(Main3Activity.this, Main2Activity.class));
                     }
                     else
                    {
                        Toast.makeText(getApplicationContext(), "istnieje już radio o podanej nazwie", Toast.LENGTH_SHORT).show();
                    }

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "pola Nazwa oraz URI nie mogą być puste", Toast.LENGTH_SHORT).show();

                }
            //
                //    Toast.makeText(getApplicationContext(), a.toString() , Toast.LENGTH_SHORT).show();
            }
        });

        getImages();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        final RecyclerView recyclerView = findViewById(R.id.recycler);
        recyclerView.setLayoutManager(layoutManager);
        final RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, checkBox, img);
        recyclerView.setAdapter(adapter);

        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {

            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView recyclerView, @NonNull MotionEvent motionEvent) {
              /*  ArrayList<Boolean> checkBox = new ArrayList<>();
                checkBox = adapter.getDataCheck();
                ArrayList<Integer> img = new ArrayList<>();
                img = adapter.getDataImg();
                checkBox.get(0).booleanValue();
                Boolean a =  checkBox.get(0).booleanValue();
                String b = a.toString();
*/

                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView recyclerView, @NonNull MotionEvent motionEvent) {
               // Toast.makeText(getApplicationContext(), "xD" , Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean b) {
              //  Toast.makeText(getApplicationContext(), "xD" , Toast.LENGTH_SHORT).show();

            }
        });






    }
    private void getImages(){


        img.add(R.drawable.a1);
        checkBox.add(false);

        img.add(R.drawable.a2);
        checkBox.add(false);

        img.add(R.drawable.a3);
        checkBox.add(false);

        img.add(R.drawable.a4);
        checkBox.add(false);

        img.add(R.drawable.a5);
        checkBox.add(false);

        img.add(R.drawable.a6);
        checkBox.add(false);

        img.add(R.drawable.a7);
        checkBox.add(false);

        img.add(R.drawable.a8);
        checkBox.add(false);






    }
    @Override
    public void onBackPressed() {

        startActivity(new Intent(Main3Activity.this, Main2Activity.class));
    }

}

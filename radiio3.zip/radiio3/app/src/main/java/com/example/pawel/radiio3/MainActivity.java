package com.example.pawel.radiio3;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    public static MediaPlayer mediaPlayer;
    public static ImageView ImageRadio;
    public static TextView TextRadio;
    public static SQLiteDatabase myDB;
    public static String text="";
    Context context =this;
    public static int nextI=0;

    String uri="";
    ProgressDialog progress;
    public static int image;
    String url_radio;
    ImageButton buttonMenu,Play,Prev,Next;
    Boolean isPlaying;
    Intent intent = getIntent();
    static Boolean isFirstTime = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ImageRadio = (ImageView)findViewById(R.id.ImageRadio);
        TextRadio = (TextView)findViewById(R.id.TextRadio);
        intent = getIntent();

        try {
            intent = getIntent();

            text = intent.getStringExtra("text");
            uri = intent.getStringExtra("uri");
            image = intent.getIntExtra("image", -1);
        }
        catch (Exception ex)
        {

            text= "";
            uri= "";
            image = -1;
        }

        if(isFirstTime) {
            mediaPlayer = new MediaPlayer();

            isFirstTime = false;
        }


        TextRadio.setText(text);
        if(image != -1)
            ImageRadio.setImageResource(image);


        myDB = openOrCreateDatabase("my.db", MODE_PRIVATE, null);
        myDB.execSQL(
                "CREATE TABLE IF NOT EXISTS user (name VARCHAR(200), uri VARCHAR(200), img VARCHAR(200))"

        );


        Play = (ImageButton) findViewById(R.id.Play);
        Play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (!mediaPlayer.isPlaying()) {


                    mediaPlayer.start();
                    Play.setImageResource(R.drawable.pause);
                    if (!mediaPlayer.isPlaying())
                        Play.setImageResource(R.drawable.playbutton);

                } else {

                    mediaPlayer.pause();
                    Play.setImageResource(R.drawable.playbutton);
                }
            }
        });

        buttonMenu = (ImageButton) findViewById(R.id.Menu);
        buttonMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainActivity.this, Main2Activity.class));
            }
        });
        Next = (ImageButton)findViewById(R.id.Next);
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

if(Main2Activity.lista.size()>0) {
   // nextI++;
    int a =Main2Activity.lista.size();
    int b = nextI;

    if((Main2Activity.lista.size()-1)>nextI) {
        nextI++;

    progress = new ProgressDialog(context);
    progress.setTitle("Ładowanie");
    progress.setMessage("Proszę poczekać...");
    progress.setCancelable(false); // disable dismiss by tapping outside of the dialog
    progress.show();

        text= Main2Activity.lista.get(nextI).name;
        image = Main2Activity.lista.get(nextI).image;

    // Main2Activity.lista.get(0).name;
    TextRadio.setText(Main2Activity.lista.get(nextI).name);
    ImageRadio.setImageResource(Main2Activity.lista.get(nextI).image);
    uri = Main2Activity.lista.get(nextI).uri;

    SearchThread searchThread = new SearchThread();
    searchThread.start();
}
   // nextI++;
}
            }
});

        Prev = (ImageButton)findViewById(R.id.Prev);
        Prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Main2Activity.lista.size()>0) {

                    if(nextI!=0)
                    {
                    nextI--;

               //     if (nextI <= 0)
                 //       nextI = Main2Activity.lista.size();

                    progress = new ProgressDialog(context);
                    progress.setTitle("Ładowanie");
                    progress.setMessage("Proszę poczekać...");
                    progress.setCancelable(false); // disable dismiss by tapping outside of the dialog
                    progress.show();


                        text= Main2Activity.lista.get(nextI).name;
                        image = Main2Activity.lista.get(nextI).image;
                    // Main2Activity.lista.get(0).name;
                    TextRadio.setText(Main2Activity.lista.get(nextI).name);
                    ImageRadio.setImageResource(Main2Activity.lista.get(nextI).image);
                    uri = Main2Activity.lista.get(nextI).uri;

                    SearchThread searchThread = new SearchThread();
                    searchThread.start();

                    // nextI++;
                }}
            }
        });


        // MediaPlayer mediaPlayer = new MediaPlayer(MainActivity.this, Uri.parse("http://rdc.pl/wp-content/uploads/2015/07/Ada-Jaroszewicz1.mp3"));
        if (mediaPlayer.isPlaying())
            Play.setImageResource(R.drawable.pause);
        else if (!mediaPlayer.isPlaying())
            Play.setImageResource(R.drawable.playbutton);


    }
    private class SearchThread extends Thread {




        @Override
        public void run() {

            MainActivity.mediaPlayer.pause();
            MainActivity.mediaPlayer.stop();
            MainActivity.mediaPlayer = new MediaPlayer();

            try {

                MainActivity.mediaPlayer.setDataSource(uri);
                MainActivity.mediaPlayer.prepare();
            }
            catch (Exception ex)
            {
                String e = ex.toString();
            }

            handler.sendEmptyMessage(0);
        }

        private Handler handler = new Handler() {

            @Override
            public void handleMessage(Message msg) {
                // displaySearchResults(search);
                Play.setImageResource(R.drawable.playbutton);
                progress.dismiss();
              //  startActivity(intent);
            }
        };
    }
}




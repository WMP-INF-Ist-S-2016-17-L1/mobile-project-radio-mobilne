package com.example.pawel.radiio3;

import android.widget.ImageView;

public class RadioAdapter {
    public int image;
    public String name;
    public String uri;


    public  RadioAdapter (int image, String name, String uri) {
        super();
        this.uri = uri;
        this.image = image;
        this.name = name;
    }
}
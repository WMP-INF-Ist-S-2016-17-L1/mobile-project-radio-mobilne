package com.example.pawel.radiio3;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

        import java.util.ArrayList;
        import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class  RadioArrayAdapter  extends ArrayAdapter<RadioAdapter> {

    private TextView name;
   private ImageView image;
   private ImageView button;
   private String uri;
    private List<RadioAdapter> roomList = new ArrayList<RadioAdapter>();
    private Context context;


    @Override
    public void add(RadioAdapter object) {
        roomList.add(object);
        super.add(object);
    }

    public  RadioArrayAdapter (Context context, int textViewResourceId) {
        super(context, textViewResourceId);
        this.context = context;
    }

    public int getCount() {
        return this.roomList.size();
    }

    public RadioAdapter getItem(int index) {
        return this.roomList.get(index);
    }

    public View getView(final int position, View convertView, ViewGroup parent) {
        final RadioAdapter radioObj = getItem(position);
        View row = convertView;
        LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        row = inflater.inflate(R.layout.listviewitem, parent, false);
        button = (ImageView) row.findViewById(R.id.imageView2) ;
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String NAME = "'"+radioObj.name+"'";
                String URI = "'"+radioObj.uri+"'";
                String IMG = "'"+String.valueOf(radioObj.image)+"'";

                MainActivity.myDB.execSQL(
                        "DELETE FROM user WHERE name ="+NAME
                );
                if(MainActivity.nextI>position)
                    MainActivity.nextI--;

// +"AND WHERE 'uri'="+URI+"AND WHERE 'img'="+IMG
                roomList.remove(position);
            //    Main2Activity.lista.remove(position);
                notifyDataSetChanged();
            }

        });
        name = (TextView) row.findViewById(R.id.nameRadio);
        name.setText(radioObj.name);

        image = (ImageView) row.findViewById(R.id.imageView);
        image.setImageResource(radioObj.image);

        image = (ImageView) row.findViewById(R.id.imageView2);
        image.setImageResource(R.drawable.minus);

uri = radioObj.uri;

        return row;
    }
}
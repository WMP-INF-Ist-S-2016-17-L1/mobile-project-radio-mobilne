package com.example.pawel.radiio3;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;

import java.util.ArrayList;

public class RecyclerViewAdapter extends  RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {


    private  ArrayList<Boolean> checkBox = new ArrayList<>();
    private  ArrayList<Integer> img = new ArrayList<>();
    private Context mContext;
    private int lastSelectedPosition = -1;
    public static int imageForList;

    public RecyclerViewAdapter(Context mContext, ArrayList<Boolean> checkBox, ArrayList<Integer> img) {
        this.checkBox = checkBox;
        this.img = img;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_listitem,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {

      //  Glide.with(mContext)
     //           .asBitmap()
       //         .load(img.get(i))
         //       .into(viewHolder.imageRadio);

        viewHolder.imageRadio.setImageResource(img.get(i));
        viewHolder.imageRadio.setTag(img.get(i));

       // viewHolder.checkRado.setChecked(checkBox.get(i).booleanValue());
        viewHolder.checkRado.setChecked(lastSelectedPosition == i);
        checkBox.set(i,viewHolder.checkRado.isChecked());
        if(checkBox.get(i)==true)
            imageForList = img.get(i);
      /*  viewHolder.imageRadio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });*/





    }

    @Override
    public int getItemCount() {
        return img.size();
    }

    public ArrayList<Boolean> getDataCheck()
    {

        return checkBox;
    }
    public ArrayList<Integer> getDataImg()
    {

        return img;
    }

    public class ViewHolder extends RecyclerView.ViewHolder  {

        ImageView imageRadio;
        RadioButton checkRado;

        public ViewHolder(View itemView){
            super(itemView);
            imageRadio = itemView.findViewById(R.id.logoImage);
            checkRado = itemView.findViewById(R.id.checkLogo);


            checkRado.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    lastSelectedPosition = getAdapterPosition();

                    notifyDataSetChanged();

                }
            });
        }

    }


}
